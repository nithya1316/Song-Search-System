const express = require('express');
const { Pool } = require('pg');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 4000;

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Initialize a PostgreSQL database connection pool
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'postgres',
    password: 'Kishoore1316',
    port: 5432,
});

app.use(bodyParser.json());
// Create a new song
app.post('/api', async (req, res) => {
    try {
        const { song_name, artist, music_director, movie } = req.body;
        const result = await pool.query(
            'INSERT INTO songs (song_name,artist,music_director,movie) VALUES ($1,$2,$3,$4) RETURNING *',
            [song_name, artist, music_director, movie]
        );
        res.json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
// Get all songs
app.get('/api/display', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM songs');
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update a song by song name
app.put('/api/update', async (req, res) => {
    const { song_name, field, new_value } = req.body;

    if (!song_name || !field || !new_value) {
        return res.status(400).json({ error: 'Song name, field, and new_value are mandatory fields' });
    }

    try {
        const updateFieldQuery = `UPDATE songs SET ${field} = $1 WHERE song_name = $2`;
        await pool.query(updateFieldQuery, [new_value, song_name]);
        res.json({ message: `${field} updated successfully` });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Fetch information of a song by its name
app.post('/api/song', async (req, res) => {
    const { song_name } = req.body;

    if (!song_name) {
        return res.status(400).json({ error: 'Song name is required in the request body' });
    }

    try {
        // Implement the SQL query to retrieve information of the song by its name
        const query = 'SELECT * FROM songs WHERE song_name = $1';
        const result = await pool.query(query, [song_name]);

        // Check if a song with the provided name exists
        if (result.rows.length === 0) {
            // Song not found, return a 404 status code
            res.status(404).json({ error: 'Song not found' });
        } else {
            // Send the song information as a JSON response
            const songInformation = result.rows[0];
            res.json(songInformation);
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Delete a song
app.delete('/api/song', async (req, res) => {
    try {
        const { song_name } = req.body;

        if (!song_name) {
            return res.status(400).json({ error: 'song_name is required in the request body' });
        }

        // Delete the song based on the provided song name
        const result = await pool.query('DELETE FROM songs WHERE song_name = $1', [song_name]);

        if (result.rowCount > 0) {
            // Song(s) deleted successfully
            res.json({ message: 'Song(s) deleted successfully' });
        } else {
            // Song not found, return a 404 status code
            res.status(404).json({ error: 'Song not found' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
